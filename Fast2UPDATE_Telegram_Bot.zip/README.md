
# Fast2UPDATE Telegram Bot

This bot automatically checks job update websites and sends alerts to your Telegram.

## Setup

1. Rename `.env.example` to `.env` and fill in your `BOT_TOKEN` and `CHAT_ID`.
2. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. Run locally:
   ```bash
   python bot.py
   ```
4. To deploy on Railway:
   - Upload this project
   - Add environment variables from `.env`
   - Deploy and you're done!

## Sites Monitored

- sarkariresult.com
- fastjobsearchers.com
- biharhelp.com
- onlineupdatestm.com
- sarkariexam.com
